# Simple Frogger Game.  Mark Handley, UCL, 2018

from fr_controller import Controller

game = Controller()
game.run()
